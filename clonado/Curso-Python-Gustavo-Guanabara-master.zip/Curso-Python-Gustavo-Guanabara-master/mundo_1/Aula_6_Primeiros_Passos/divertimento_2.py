n = input("Digite algo: \n")
