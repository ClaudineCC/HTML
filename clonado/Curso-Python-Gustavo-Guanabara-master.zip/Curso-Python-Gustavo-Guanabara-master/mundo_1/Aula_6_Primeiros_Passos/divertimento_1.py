# Tipos primitivos: int()

n1 = int(input("Digite um valor: \n"))
n2 = int(input("Digite outro valor :\n"))
s = n1 + n2
print("A soma entre {} e {} vale {}.".format(n1, n2, s))
