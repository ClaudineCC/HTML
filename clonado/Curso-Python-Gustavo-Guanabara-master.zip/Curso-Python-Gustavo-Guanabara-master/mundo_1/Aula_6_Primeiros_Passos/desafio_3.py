# Crie um programa que leia dois números e mostre a soma entre eles

n1 = int(input("Digite um número: \n"))
n2 = input("Digite outro número: \n")
s = n1 + n2
print(s)
