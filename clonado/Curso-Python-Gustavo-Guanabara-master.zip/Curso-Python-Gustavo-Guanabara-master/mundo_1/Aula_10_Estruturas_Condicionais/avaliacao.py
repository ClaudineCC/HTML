# Rascunho para a avaliação

'''
texto = 'Tres Pratos de Trigo para Tigres Tristes'
total = texto.upper().count(texto[0])
print(total)
print(texto[0])
'''
