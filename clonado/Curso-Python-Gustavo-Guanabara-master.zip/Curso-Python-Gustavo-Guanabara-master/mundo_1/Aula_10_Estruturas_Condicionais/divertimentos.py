nome = str(input("Qual é o seu nome? \n")).lower()
if nome == "kendrick":
    print("Que nome lindo você tem, {}!".format(nome))
else:
    print("Seu nome é tão normal, {}.".format(nome))
print("Bom dia, {}.".format(nome))
