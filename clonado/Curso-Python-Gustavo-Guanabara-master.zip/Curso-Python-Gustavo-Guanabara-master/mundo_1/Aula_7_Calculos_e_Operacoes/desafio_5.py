# Faça um programa que leia um número inteiro e mostre na tela o seu sucessor e seu antecessor:

n = int(input("Digite um número: \n"))
print("O antecessor do número {} é: {}.".format(n, n - 1))
print("O sucessor do número {} é: {}.".format(n, n + 1))
