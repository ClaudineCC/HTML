# Crie um script Python que leia o nome de uma pessoa e mostre uma mensagem de boas-vindas de acordo com o valor digitado

entrada = input("Digite seu nome: \n")
print("Olá, {}! Prazer em conhecer você!".format(entrada))

# Crie um programa que escreva "Olá, mundo" na tela.

print("Olá, mundo!")
msg = "Hello, world!"
print(msg)
