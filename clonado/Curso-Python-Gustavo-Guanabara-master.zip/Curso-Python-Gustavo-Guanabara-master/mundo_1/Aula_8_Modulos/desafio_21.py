# Faça um programa em Python que abra e reproduza um arquivo mp3
'''
import pygame
pygame.init()
pygame.mixer.music.load("desafio_21_city_escape.mp3")
pygame.mixer.music.play()
input("Agora você escuta?")
'''

# Não rodou.
