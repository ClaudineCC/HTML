from math import sqrt, ceil

num = int(input("Digite um número: \n"))
raiz = sqrt(num)
print("A raiz de {} é igual a {}!".format(num, ceil(raiz)))
