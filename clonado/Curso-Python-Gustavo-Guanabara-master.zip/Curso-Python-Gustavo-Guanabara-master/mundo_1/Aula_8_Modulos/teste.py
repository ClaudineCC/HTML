import emoji
print(emoji.emojize("Hello, World! :earth_americas:", use_aliases=True))
