for j in range(5, -1, -1):
    print(j)
print("Fim do laço 2.")
n = int(input("Digite um número: \n"))
for k in range(0, n + 1):
    print(k)
print("Fim do laço 3.")
