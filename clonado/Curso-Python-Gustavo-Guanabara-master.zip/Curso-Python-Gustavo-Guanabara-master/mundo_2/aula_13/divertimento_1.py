for i in range(1, 5):
    print("{}: oi".format(i))
print("fim do laço 1.")
