# Teste de expressão regular

import re

resultados = re.findall("[A-Za-z]y", "Python ou jython")
print(resultados)