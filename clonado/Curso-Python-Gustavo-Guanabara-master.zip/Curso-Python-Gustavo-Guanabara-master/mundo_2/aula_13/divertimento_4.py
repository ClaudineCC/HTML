# Soma:

s = 0
for n in range(0, 2):
    p = int(input("Número para somar: \n"))
    s += p
print("A soma é {}.".format(s))
