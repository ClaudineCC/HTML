inicio = int(input("Início: \n"))
fim = int(input("Fim: \n"))
passo = int(input("Passo: \n"))

for m in range(inicio, fim + 1, passo):
    print(m)
print("fim do laço 4")
