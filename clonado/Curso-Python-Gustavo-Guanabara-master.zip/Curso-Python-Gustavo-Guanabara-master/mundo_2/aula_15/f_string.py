nome = "José"
idade = 33
salario = 987.35
print(f"O {nome} tem {idade} anos.")

# Método pra formatar float continua igual:
print(f"O {nome} tem {idade} anos e ganha R${salario:.1f} de salário.")
