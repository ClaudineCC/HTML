i =
while i < 5:
    print("Olá, mundo!")
    i += 1

