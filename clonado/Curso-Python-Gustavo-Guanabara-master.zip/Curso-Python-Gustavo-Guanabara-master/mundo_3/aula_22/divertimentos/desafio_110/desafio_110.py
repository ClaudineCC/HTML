"""
Adicione ao módulo moeda.py, criado nos exercícios anteriores, uma função chamada resumo(), que mostre na tela algumas informações geradas pelas funções que já temos no módulo criado até aqui.
"""

import moeda

# input_usuario = float(input("Digite o preço: \n"))
input_usuario = 558

print(moeda.resumo(input_usuario, 20, 12))
