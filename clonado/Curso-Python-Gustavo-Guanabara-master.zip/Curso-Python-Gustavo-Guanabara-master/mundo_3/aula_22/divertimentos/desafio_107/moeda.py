def dobro(num):
    return num * 2


def metade(num):
    return num / 2


def aumentar(num, taxa):
    resultado = num + (taxa * num / 100)
    return resultado


def diminuir(num, taxa):
    resultado = num - (taxa * num / 100)
    return resultado
