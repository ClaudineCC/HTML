    # if nome == 0:
    #     nome = "Desconhecido"
